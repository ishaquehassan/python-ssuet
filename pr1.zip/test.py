a = 2
b = 3
c = a+b
print(c)


def hello(a,b):
    return a+b


def test():
    print("Hello world")


name = "Ishaq"
print(name)

print(hello(2,5))
